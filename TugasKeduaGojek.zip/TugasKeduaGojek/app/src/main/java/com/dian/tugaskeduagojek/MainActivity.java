package com.dian.tugaskeduagojek;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void GambarSEND(View view) {
        Intent intent = new Intent(MainActivity.this, GambarSEND.class);
        startActivity(intent);
    }

    public void GambarRIDE(View view) {
        Intent intent = new Intent(MainActivity.this, GambarRIDE.class);
        startActivity(intent);
    }

    public void GambarFOOD(View view) {
        Intent intent = new Intent(MainActivity.this, GambarFOOD.class);
        startActivity(intent);
    }

    public void GambarMART(View view) {
        Intent intent = new Intent(MainActivity.this, GambarMART.class);
        startActivity(intent);
    }
}
