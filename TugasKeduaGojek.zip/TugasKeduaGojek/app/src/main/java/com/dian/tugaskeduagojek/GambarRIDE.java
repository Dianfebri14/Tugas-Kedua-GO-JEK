package com.dian.tugaskeduagojek;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class GambarRIDE extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gambar_ride);
    }
}
